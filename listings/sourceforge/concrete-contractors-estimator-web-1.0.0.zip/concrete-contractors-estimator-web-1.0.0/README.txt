Concrete Contractors Estimator - offline web calculator

Open index.html in any browser. No install, no network calls.
Slab, driveway, patio, footing, column and steps volume in cubic yards, 80/60/40 lb bag counts, rebar and mesh, rough cost and hot-weather pour advice.

Homepage: https://concretecontractorsphoenix.net/
Source: https://github.com/nbkdevs/concrete-contractors-phoenix
License: MIT
